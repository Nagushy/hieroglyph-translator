# Hieroglyph Translator

A Pen created on CodePen.io. Original URL: [https://codepen.io/Mahmoud-Nagy-the-selector/pen/OJKVEVp](https://codepen.io/Mahmoud-Nagy-the-selector/pen/OJKVEVp).

