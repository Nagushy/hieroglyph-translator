// Updated Hieroglyph dictionary mapping based on Gardiner's Sign List
const hieroglyphDictionary = {
    "a": "𓄿",
    "b": "𓃀",
    "c": "𓍿",
    "d": "𓂧",
    "e": "𓇋",
    "f": "𓆑",
    "g": "𓎼",
    "h": "𓉔",
    "i": "𓇋",
    "j": "𓆓",
    "k": "𓎡",
    "l": "𓃭",
    "m": "𓅓",
    "n": "𓈖",
    "o": "𓅱",
    "p": "𓊪",
    "q": "𓈎",
    "r": "𓂋",
    "s": "𓈙",
    "t": "𓏏",
    "u": "𓅱",
    "v": "𓆑",
    "w": "𓅱",
    "x": "𓐍",
    "y": "𓇌",
    "z": "𓊃"
};

// Function to translate English word to hieroglyphs
function translateToHieroglyphs(word) {
    return word.toLowerCase().split('').map(letter => hieroglyphDictionary[letter] || letter).join('');
}

// DOM Elements
const translateButton = document.getElementById('translate-button');
const hieroglyphOutput = document.getElementById('hieroglyph-output');

// Event Listener for the translate button
translateButton.addEventListener('click', () => {
    const englishWord = document.getElementById('english-input').value;
    const hieroglyphTranslation = translateToHieroglyphs(englishWord);
    hieroglyphOutput.textContent = hieroglyphTranslation;
});
